function [sums,order]= varOrder2(prev,this,prevDims,thisDims,option)
%VARORDER1 种群中个体的决策变量顺序匹配问题
%   将两种群中个体的每个决策变量到该决策变量均值的平均距离最近的匹配
%prev代表前一种群，mPrev代表前一种群的均值; this代表当前种群，mThis代表当前种群的均值,option代表选择距离最大还是最小
sub_pop=length(this);
prevMax=max(reshape([prev.Dec],prevDims,[]),[],2)';
prevMin=min(reshape([prev.Dec],prevDims,[]),[],2)';
thisMax=max(reshape([this.Dec],thisDims,[]),[],2)';
thisMin=min(reshape([this.Dec],thisDims,[]),[],2)';
prevRange=prevMax-prevMin;
thisRange=thisMax-thisMin;

mPrev=mean(reshape([prev.Dec],prevDims,[]),2)';
mThis=mean(reshape([this.Dec],thisDims,[]),2)';
temp1=power((reshape([prev.Dec],prevDims,[])'-mPrev),2);
temp2=power((reshape([this.Dec],thisDims,[])'-mThis),2);

sum2=sum(temp2,1)/(sub_pop-1);
sums=0;order=zeros(1,thisDims);
if option ==1 
    opt=1;
end
if option ==0
    opt=randi([1,prevDims]);
end
if option ==2 
    opt=2;
end

for i=1:thisDims
    for j=1:prevDims
        if  prevRange(j)~=thisRange(i)
            temp1(j)=power(power(temp1(j),1/2)*(thisRange(i)/prevRange(j)),2);
        end
    end
    sum1=sum(temp1,1)/(sub_pop-1);
    KLD=zeros(1,prevDims);
    for j=1:prevDims
        KLD(j)=log2(power(sum1(j),1/2)/power(sum2(i),1/2))+(sum2(i)+power((mPrev(j)-mThis(i)),2))/(2*sum1(j))-1/2;
    end
    [d,a]=sort(KLD);
    sums=sums+d(opt);
    order(i)=a(opt);
end
end
