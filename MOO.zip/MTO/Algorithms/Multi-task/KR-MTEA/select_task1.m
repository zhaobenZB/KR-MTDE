function index = select_task1(table,n)
%SELECT_TASK 此处显示有关此函数的摘要
%   此处显示详细说明
sums=0;g_table=ones(1,length(table));
for i=1:length(table)
    sums=sums+table(i);
end
for i=1:length(table)
    if i==1
        g_table(i)=table(i)/sums;
    else
        g_table(i)=g_table(i-1)+table(i)/sums;
    end
end
a=rand;rand_n=ones(1,n+1)/(n+1);index=zeros(1,n);
for i=1:n
    rand_n(i)=rem(a+i/(n+1),1);
end
for j=1:n
for i=1:length(table)
    if i==1
        if rand_n(j)<=g_table(i)
            index(j)=i;
        else
            continue
        end
    else
        if rand_n(j)>g_table(i-1)&& rand_n(j)<=g_table(i)
            index(j)=i;
        end
    end
end
end
end

