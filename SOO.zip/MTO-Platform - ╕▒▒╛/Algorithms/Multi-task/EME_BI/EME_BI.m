classdef EME_BI < Algorithm
    % <Many> <None>
    
    properties (SetAccess = private)
        mu = 2;
        mum = 5;
        amp0 = 0.9
        K = 10;
        ktn = 5;
    end
    
    methods
        function parameter = getParameter(obj)
            parameter = {'mu: index of Simulated Binary Crossover', num2str(obj.mu), ...
                'mum: index of polynomial mutation', num2str(obj.mum), ...
                'amp0: initial amp', num2str(obj.amp0), ...
                'K: cluster num', num2str(obj.K), ...
                'ktn: knowledge transfer tasks num', num2str(obj.ktn)};
        end
        
        function obj = setParameter(obj, parameter_cell)
            count = 1;
            obj.mu = str2double(parameter_cell{count}); count = count + 1;
            obj.mum = str2double(parameter_cell{count}); count = count + 1;
            obj.amp0 = str2double(parameter_cell{count}); count = count + 1;
            obj.K = str2double(parameter_cell{count}); count = count + 1;
            obj.ktn = str2double(parameter_cell{count}); count = count + 1;
        end
        
        function data = run(obj, Tasks, run_parameter_list)
            sub_pop = run_parameter_list(1);
            sub_eva = run_parameter_list(2);
            pop_size = sub_pop * length(Tasks);
            eva_num = sub_eva * length(Tasks);
            tic
            
            % initialize
            [population, fnceval_calls, bestobj, data.bestX] = initializeMF(Individual, pop_size, Tasks, max([Tasks.dims]));
            D0=zeros(1,length(Tasks));Pk=cell(length(Tasks),1);
            for t=1:length(Tasks)
                Pk{t}=population([population.skill_factor] == t);
                for j=1:length(Pk{t})
                    costs=reshape([Pk{t}.factorial_costs],length(Pk{t}(1).factorial_costs),[])';
                    w=1-Pk{t}(j).factorial_costs(t)/sum(costs(:,t));
                    [~,ids]=min(costs(:,t));
                    gbest=Pk{t}(ids);
                    D0(t)=D0(t)+w.*power(sum(power(Pk{t}(j).rnvec-gbest.rnvec,2)),1/2);
                end
            end
            RMP=ones(length(Tasks),length(Tasks))*0.3;
            S=cell(length(Tasks),length(Tasks));
            c=0.06;gamma=0.3;m=2; F=0.5;CR=0.9;
            eta=ones(m,length(Tasks));mFE=zeros(m,length(Tasks));mf=zeros(m,length(Tasks));
            delta=cell(length(Tasks),length(Tasks));
            data.convergence(:, 1) = bestobj;
            generation = 1; N=sub_pop;
            while fnceval_calls < eva_num
                generation = generation + 1;
                %  recombination
                [~,frank]=sort(reshape([population.factorial_costs],length(Tasks),[]),2);
                scalar=min(frank);
                [~,rank]=sort(scalar);
                population=population(rank(1:N*length(Tasks)/2));
                %       generation
                [offspring, calls, S,delta] = OperatorEMEBI.generate(1, population, Tasks, RMP,S,delta, obj.mu, obj.mum);
                fnceval_calls = fnceval_calls + calls;
                %       select
                temp=[population,offspring];
                %                 temp(N*length(Tasks)/2+1:N*length(Tasks))=offspring;
                [~,frank]=sort(reshape([temp.factorial_costs],length(Tasks),length(temp)),2);
                scalar=min(frank);
                [~,rank]=sort(scalar);
                
                population=temp(rank(1:N*length(Tasks)));
                for t=1:length(Tasks)
                    for st=1:length(Tasks)
                        if st~=t
                            if isempty(S{t,st})
                                RMP(t,st)=(1-c)*RMP(t,st);
                            else
                                w=delta{t,st}./sum(delta{t,st});
                                meanwl=sum(w.*power(S{t,st},2))/sum(w.*S{t,st});
                                RMP(t,st)=RMP(t,st)+c*meanwl;
                            end
                        end
                    end
                end
                
                %  learning
                Pk=cell(t,1);
                for t=1:length(Tasks)
                    % Divide P(t) into K sub-populations for K tasks;
                    [~,frank]=sort(reshape([population.factorial_costs],length(Tasks),[]),2);
                    Pk{t}=population(frank(t,1:N));
%                     Pk{t}=population([population.skill_factor] == t);
%                     if length(Pk{t})<20
%                         Pk{t}=[Pk{t},population(randi(end,1,20-length(Pk{t})))];
%                     end
                    plist=cell(m,1);
                    li=[1:length(Pk{t})];
                    for i=1:m
                        if i==1
                            mli=li(randperm(length(li),round((1-(m-1)*gamma)*length(Pk{t}))));
                        else
                            mli=li(randperm(length(li),min(length(li),round(gamma*length(Pk{t})))));
                        end
                        li(ismember(li,mli))=[];
                        plist{i}=Pk{t}(mli);
                    end
                    Pk{t}=[];
                    % Assign search operators to the sets based on their performance
                    mlist=randperm(m,m);
                    [~,mrank]=max(eta(:,t));
                    mlist(mlist==mrank)=mlist(1);
                    mlist(1)=mrank;
                    % evolve
                    for i=1:m
                        if mlist(i)==1
                            % DE/pbest/1/bin
                            costs=reshape([plist{i}.factorial_costs],length(Tasks),[]);
                            [~,rank]=sort(costs(t,:));
                            Xgb = plist{i}(rank(ceil(rand(1,length(plist{i})).*max(2,rand(1,length(plist{i}))*0.1*length(plist{i})))));
                            Xr1 = plist{i}(randi(end,1,length(plist{i})));
                            Xr2 = plist{i}(randi(end,1,length(plist{i})));
                            for j=1:length(plist{i})
                                for k=1:length(Xgb(j).rnvec)
                                    if rand<CR || k==randi(length(Xgb(j).rnvec))
                                        offspring(j).rnvec(k)=Xgb(j).rnvec(k) + F * (Xr1(j).rnvec(k) - Xr2(j).rnvec(k));
                                    else
                                        offspring(j).rnvec(k)=plist{i}(j).rnvec(k);
                                    end
                                end
                                offspring(j).rnvec(offspring(j).rnvec > 1) = 1;
                                offspring(j).rnvec(offspring(j).rnvec < 0) = 0;
                                offspring(j).skill_factor=t;
                                [offspring(j), cal] = evaluate(offspring(j), Tasks(t), 1);
                                fnceval_calls=fnceval_calls+cal;
                                mFE(mlist(i),t)=mFE(mlist(i),t)+cal;
                            end
                            
                            if offspring(j).factorial_costs(t)<plist{i}(j).factorial_costs(t)
                                plist{i}(j)=offspring(j);
                                mf(mlist(i),t)=mf(mlist(i),t)+plist{i}(j).factorial_costs(t)-offspring(j).factorial_costs(t);
                            else
                                w=1-plist{i}(j).factorial_costs(t)/sum(costs(t,:));
                                [~,ids]=min(costs(t,:));
                                gbest=plist{i}(ids);
                                
                                sigma=(D0(t)-sum(w.*power(sum(power(plist{i}(j).rnvec-gbest.rnvec,2)),1/2)))/D0(t);
                                preplace=sigma*exp((plist{i}(j).factorial_costs(t)-offspring(j).factorial_costs(t))/(1e3-1e-6));
                                if rand<preplace
                                    plist{i}(j)=offspring(j);
                                end
                            end
                            eta(mlist(i),t)=mf(mlist(i),t)/mFE(mlist(i),t);
                        end
                        if mlist(i)==2
                            % Gaussian Mutation
                            for j=1:length(plist{i})
                                offspring(j) = OperatorGA.mutate(plist{i}(j), max([Tasks.dims]), obj.mum);
                                offspring(j).skill_factor=t;
                                [offspring(j), cal] = evaluate(offspring(j), Tasks(offspring(j).skill_factor), 1);
                                fnceval_calls=fnceval_calls+cal;
                                mFE(mlist(i),t)=mFE(mlist(i),t)+cal;
                            end
                            
                            if offspring(j).factorial_costs(t)<plist{i}(j).factorial_costs(t)
                                plist{i}(j)=offspring(j);
                                mf(mlist(i),t)=mf(mlist(i),t)+plist{i}(j).factorial_costs(t)-offspring(j).factorial_costs(t);
                            else
                                costs=reshape([plist{i}.factorial_costs],length(Tasks),[]);
                                w=1-plist{i}(j).factorial_costs(t)/sum(costs(t,:));
                                [~,ids]=min(costs(t,:));
                                gbest=plist{i}(ids);
                                
                                sigma=(D0(t)-sum(w.*power(sum(power(plist{i}(j).rnvec-gbest.rnvec,2)),1/2)))/D0(t);
                                preplace=sigma*exp((plist{i}(j).factorial_costs(t)-offspring(j).factorial_costs(t))/(1e6-1e-6));
                                if rand<preplace
                                    plist{i}(j)=offspring(j);
                                end
                            end
                            eta(mlist(i),t)=mf(mlist(i),t)/mFE(mlist(i),t);
                        end
                        Pk{t}=[Pk{t},plist{i}];
                    end
                    costs=reshape([plist{i}.factorial_costs],length(Tasks),[]);
                    [bestobj_now,idx]=min(costs(t,:));
%                     [bestobj_now, idx] = min([Pk{t}.factorial_costs]);
                    if bestobj_now < bestobj(t) && bestobj_now>=0
                        bestobj(t) = bestobj_now;
                        data.bestX{t} = Pk{t}(idx).rnvec;
                    end
                end
                population=[];
                for t=1:length(Tasks)
                    population=[population,Pk{t}];
                end
                
                
                data.convergence(:, generation) = bestobj;
            end
            data.bestX = uni2real(data.bestX, Tasks);
            data.clock_time = toc;
        end
        
        
        
    end
end
