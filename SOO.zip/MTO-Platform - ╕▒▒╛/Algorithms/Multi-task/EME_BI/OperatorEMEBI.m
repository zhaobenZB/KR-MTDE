classdef OperatorEMEBI < Operator

    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 Yanchi Li. You are free to use the MTO-Platform for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "MTO-Platform" and cite
    % or footnote "https://github.com/intLyc/MTO-Platform"
    %--------------------------------------------------------------------------

    methods (Static)
        function [offspring, calls, S, delta] = generate(callfun, population, Tasks, RMP,S,delta, mu, mum)
            calls = 0;
            if isempty(population)
                offspring = population;
                return;
            end
            Individual_class = class(population(1));
            indorder1 = randperm(length(population));
            indorder2 = randperm(length(population));
            count = 1;
            for i = 1:ceil(length(population))
                p1 = indorder1(i);
                p2=indorder2(i);
%                 p2 = indorder(i + fix(length(population) / 2));
                t1=population(p1).skill_factor;
                t2=population(p2).skill_factor;
                offspring(count) = feval(Individual_class);
                offspring(count).factorial_costs = inf(1, length(Tasks));
                offspring(count).constraint_violation = inf(1, length(Tasks));
                offspring(count + 1) = feval(Individual_class);
                offspring(count + 1).factorial_costs = inf(1, length(Tasks));
                offspring(count + 1).constraint_violation = inf(1, length(Tasks));

                u = rand(1, max([Tasks.dims]));
                cf = zeros(1, max([Tasks.dims]));
                cf(u <= 0.5) = (2 * u(u <= 0.5)).^(1 / (mu + 1));
                cf(u > 0.5) = (2 * (1 - u(u > 0.5))).^(-1 / (mu + 1));

                if t1 == t2
                    % crossover
                    offspring(count) = OperatorGA.crossover(offspring(count), population(p1), population(p2), cf);
                    offspring(count + 1) = OperatorGA.crossover(offspring(count + 1), population(p2), population(p1), cf);
                    % offspring(count) = OperatorGA.mutate(offspring(count), max([Tasks.dims]), mum);
                    % offspring(count + 1) = OperatorGA.mutate(offspring(count + 1), max([Tasks.dims]), mum);
                    % imitate
                   
                    offspring(count).skill_factor = t1;
                    [offspring(count), cal] = evaluate(offspring(count), Tasks(t1), 1);
                    calls=calls+cal;
                    offspring(count + 1).skill_factor = t1;
                    [offspring(count+1), cal] = evaluate(offspring(count+1), Tasks(t1), 1);
                    calls=calls+cal;
                else
                    rmp=normrnd(max(RMP(t1,t2),RMP(t2,t1)),0.1);
                    if rand<=rmp
                        % crossover
                        offspring(count) = OperatorGA.crossover(offspring(count), population(p1), population(p2), cf);
                        offspring(count + 1) = OperatorGA.crossover(offspring(count + 1), population(p2), population(p1), cf);
                        for x=1:2
                            if rand<=RMP(t1,t2)/(RMP(t1,t2)+RMP(t2,t1))
                                offspring(count-1+x).skill_factor=t1;
                                [offspring(count-1+x), cal] = evaluate(offspring(count-1+x), Tasks(t1), 1);
                                calls=calls+cal;
                                if offspring(count-1+x).factorial_costs(t1)<population(p1).factorial_costs(t1)
                                    S{t1,t2}=[S{t1,t2},rmp];
                                    delta{t1,t2}=[delta{t1,t2},population(p1).factorial_costs(t1)-offspring(count-1+x).factorial_costs(t1)];
                                end
                            else
                                offspring(count-1+x).skill_factor=t2;
                                [offspring(count-1+x), cal] = evaluate(offspring(count-1+x), Tasks(t2), 1);
                                calls=calls+cal;
                                if offspring(count-1+x).factorial_costs(t2)<population(p2).factorial_costs(t2)
                                    S{t2,t1}=[S{t2,t1},rmp];
                                    delta{t2,t1}=[delta{t2,t1},offspring(count-1+x).factorial_costs(t2)-population(p2).factorial_costs(t2)];
                                end
                            end
                        end
                    else
                        temp1 = population([population.skill_factor] == t1);
                        a=temp1(randi(end,1));
                        offspring(count) = OperatorGA.crossover(offspring(count), population(p1), a, cf);
                        offspring(count).skill_factor = t1;
                        [offspring(count), cal] = evaluate(offspring(count), Tasks(offspring(count).skill_factor), 1);
                        calls=calls+cal;
                        temp2 = population([population.skill_factor] == t2);
                        b=temp2(randi(end,1));
                        offspring(count+1) = OperatorGA.crossover(offspring(count+1), population(p2), b, cf);
                        offspring(count+1).skill_factor = t2;
                        [offspring(count+1), cal] = evaluate(offspring(count+1), Tasks(offspring(count+1).skill_factor), 1);
                        calls=calls+cal;
                    end
                end
                for x = count:count + 1
                    offspring(x).rnvec(offspring(x).rnvec > 1) = 1;
                    offspring(x).rnvec(offspring(x).rnvec < 0) = 0;
                end
                count = count + 2;
            end
            
        end
    end
end
