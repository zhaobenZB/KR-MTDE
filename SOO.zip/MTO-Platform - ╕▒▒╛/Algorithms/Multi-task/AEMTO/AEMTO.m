classdef AEMTO < Algorithm
    % <Multi/Many> <None>
    properties (SetAccess = private)
        w=0.3;
        tsf_lb=0.05;
        tsf_ub=0.7;
        F = 0.5;
        CR = 0.5;
        mu = 2;
        mum = 5;
    end
    
    methods
        function parameter = getParameter(obj)
            parameter = {'w: The quality update coefficient', num2str(obj.w), ...
                'tsf_lb:The lower bounds of the knowledge transfer probability', num2str(obj.tsf_lb), ...
                'tsf_ub:The lower bounds of the knowledge transfer probability', num2str(obj.tsf_ub), ...
                'F: Mutation Factor', num2str(obj.F), ...
                'CR: Crossover Probability', num2str(obj.CR),...
                'mu: index of Simulated Binary Crossover', num2str(obj.mu), ...
                'mum: index of polynomial mutation', num2str(obj.mum)};
        end
        
        function obj = setParameter(obj, parameter_cell)
            count = 1;
            obj.w = str2double(parameter_cell{count}); count = count + 1;
            obj.tsf_lb = str2double(parameter_cell{count}); count = count + 1;
            obj.tsf_ub = str2double(parameter_cell{count}); count = count + 1;
            obj.F = str2double(parameter_cell{count}); count = count + 1;
            obj.CR = str2double(parameter_cell{count});count = count + 1;
            obj.mu = str2double(parameter_cell{count}); count = count + 1;
            obj.mum = str2double(parameter_cell{count});
        end
        
        function data = run(obj, Tasks, run_parameter_list)
            sub_pop = run_parameter_list(1);
            sub_eva = run_parameter_list(2);
            eva_num = sub_eva * length(Tasks);
            tic            
            nTasks=length(Tasks);
            dimTasks=ones(1,nTasks);
            for i=1:nTasks
                dimTasks(i) = Tasks(i).dims;
            end
            % initialize
            [population, fnceval_calls, bestobj, data.bestX] = initializeMT(Individual, sub_pop, Tasks, max([Tasks.dims]) * ones(1, length(Tasks)));
            data.convergence(:, 1) = bestobj;
            generation = 1;
            q_sel=zeros(nTasks,nTasks);p_sel=ones(nTasks,nTasks)/(nTasks-1);
            for t=1:nTasks
                p_sel(t,t)=0;
            end
            q_s=zeros(1,nTasks);q_o=zeros(1,nTasks);
            p_tsf=ones(1,nTasks)*(0.05+0.7)/2;p_min=0.3/(nTasks-1);
            while fnceval_calls < eva_num
                generation = generation + 1;
                for t = 1:length(Tasks)
                    if  rand<=p_tsf(t)
                        sign=1;
                        % Knowledge transfer
                        n=zeros(1,nTasks);K=population{t};m_sum=0;
                        m_l=select_task1(p_sel(t,:),nTasks-1);
                        for j=1:length(m_l)
                            m_sum=m_sum+p_sel(t,m_l(j));
                        end
                        for j=1:nTasks
                            if j~=t && ~isempty(m_l(m_l==j))
                                n(j)=floor(length(m_l(m_l==j))*sub_pop*p_sel(t,j)/m_sum);
                            end
                        end
                        for j=1:nTasks
                            num=1;
                            if j~=t && n(j)~=0
                                for i=1:n(j)
                                    K(num)=population{j}(RouletteWheelSelection(1,[population{j}.factorial_costs]));
                                    num=num+1;
                                end
                            end
                        end
                        % crossover
                        k=1;ns=zeros(1,nTasks);sum1=0;
                        offspring=population{t};
                        CR = 0.1 + (0.9 - 0.1) * rand;
                        for j=1:nTasks
                           if j~=t && n(j)~=0 
                               for s=1:n(j)
                                   v=K(k);
                                   x=population{t}(k);
                                   offspring(k) = OperatorDE.crossover(v,x,CR);
                                   [offspring(k), calls] = evaluate(offspring(k), Tasks(t), 1);
                                   fnceval_calls = fnceval_calls + calls;
                                   if offspring(k).factorial_costs<x.factorial_costs
%                                        population{t}(k)=offspring(k);
                                       ns(j)=ns(j)+1;                                       
                                   end
                                   k=k+1;
                               end
                               sum1=sum1+ns(j);
                           end
                        end
%                         q_o(t)=0.3*q_o(t)+0.7*sum1/sub_pop;
                        for j=1:nTasks
                           if j~=t && n(j)~=0 
                               q_sel(t,j)=obj.w*q_sel(t,j)+(1-obj.w)*ns(j)/n(j);
                           end
                        end
                        
                        for j=1:nTasks
                           if j~=t 
                               p_sel(t,j)=p_min+(1-(nTasks-1)*p_min)*q_sel(t,j)/(sum(q_sel(t,:))+0.001);
                           end
                        end
                    else
                        sign=0;
%                         obj.F = 0.1 + (2 - 0.1) * rand;
%                         obj.CR = 0.1 + (0.9 - 0.1) * rand;
%                         [offspring,calls] = OperatorDE.generate(1, population{t}, Tasks(t), obj.F, obj.CR, 'current_rand');
                        [offspring, calls] = OperatorDE.generate(1, population{t}, Tasks(t), obj.F, obj.CR);
%                         [offspring,calls] = OperatorGA.generate(1, population{t}, Tasks(t), obj.mu, obj.mum);
                        fnceval_calls = fnceval_calls + calls;
                        % selection
%                         replace = [population{t}.factorial_costs] > [offspring.factorial_costs];
%                         population{t}(replace) = offspring(replace);
%                         q_s(t)=0.3*q_s(t)+0.7*length(replace(replace==1))/sub_pop;
                    end
                    intpopulation(1:sub_pop)=offspring;
                    intpopulation(sub_pop+1:2*sub_pop)=population{t};
                    [~,idsCost]=sort([intpopulation.factorial_costs]);
                    intpopulation=intpopulation(idsCost);
                    population{t}=intpopulation(1:sub_pop);
                    [~,ia]=intersect(reshape([population{t}.rnvec],dimTasks(t),[])',reshape([offspring.rnvec],dimTasks(t),[])','rows');

                    if sign==0
                        q_s(t)=obj.w*q_s(t)+(1-obj.w)*length(ia)/sub_pop;
                    else
                        q_o(t)=obj.w*q_o(t)+(1-obj.w)*length(ia)/sub_pop;
                    end
                    [bestobj_now, idx] = min([population{t}.factorial_costs]);
                    if bestobj_now < bestobj(t) && bestobj_now>=0
                        bestobj(t) = bestobj_now;
                        data.bestX{t} = population{t}(idx).rnvec;
                    end
                    data.convergence(t, generation) = bestobj(t);                    
                    p_tsf(t)=obj.tsf_lb+q_o(t)/(q_o(t)+q_s(t)+0.001)*(obj.tsf_ub-obj.tsf_lb);
                end
%                 disp(p_tsf)
            end
            data.bestX = uni2real(data.bestX, Tasks);
            data.clock_time = toc;
        end
    end
end
