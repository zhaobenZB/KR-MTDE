classdef KR_MTGA < Algorithm
    % <Multi/Many> <None>
    
    properties (SetAccess = private)
        pTransfer=0.5;
        mu = 2;
        mum = 5;
        group=10;
        F = 0.5;
        CR = 0.9;
        min=0.1;
        Lb=0.1;
        Ub=0.7;
        w=0.3;
    end
    
    methods
        function parameter = getParameter(obj)
            parameter = {'pTransfer: Portion of chromosomes to transfer from one task to another', num2str(obj.pTransfer), ...
                'mu: index of Simulated Binary Crossover', num2str(obj.mu), ...
                'mum: index of polynomial mutation', num2str(obj.mum),...
                'group: size of task group', num2str(obj.group),...
                'F: Mutation Factor', num2str(obj.F), ...
                'CR: Crossover Probability', num2str(obj.CR),...
                'min: Minimum boundary value', num2str(obj.min),...
                'Lb: Lower Bound', num2str(obj.Lb),...
                'Ub: Upper Bound', num2str(obj.Ub),...
                'w:Advantage accumulation parameters', num2str(obj.w)};
        end
        
        function obj = setParameter(obj, parameter_cell)
            count = 1;
            obj.pTransfer = str2double(parameter_cell{count}); count = count + 1;
            obj.mu = str2double(parameter_cell{count}); count = count + 1;
            obj.mum = str2double(parameter_cell{count}); count = count + 1;
            obj.group = str2double(parameter_cell{count}); count = count + 1;
            obj.F = str2double(parameter_cell{count}); count = count + 1;
            obj.CR = str2double(parameter_cell{count});count = count + 1;
            obj.min = str2double(parameter_cell{count});count = count + 1;
            obj.Lb = str2double(parameter_cell{count});count = count + 1;
            obj.Ub = str2double(parameter_cell{count});count = count + 1;
            obj.w = str2double(parameter_cell{count});
        end
        
        function data = run(obj, Tasks, run_parameter_list)
            sub_pop = run_parameter_list(1);
            sub_eva = run_parameter_list(2);
            eva_num = sub_eva * length(Tasks);
            tic
            nTasks=length(Tasks);
            scale=ones(nTasks,nTasks)*obj.pTransfer; % adjust nTransfer dynamically
            trans=ones(1,nTasks)*obj.pTransfer;
            dimTasks=ones(1,nTasks);
            for i=1:nTasks
                dimTasks(i) = Tasks(i).dims;
            end
            % initialize
            [population, fnceval_calls, bestobj, data.bestX] = initializeMT(Individual, sub_pop, Tasks, [Tasks.dims]);
            data.convergence(:, 1) = bestobj;
            generation = 1;
            table=ones(nTasks,nTasks)*(obj.Lb+obj.Ub)/2;
            table1=zeros(nTasks,nTasks);
            for t=1:nTasks
                table(t,t)=0;
            end
            obj.group=nTasks-1;
            group_list=cell(1,nTasks);
            while fnceval_calls < eva_num
                generation = generation + 1;
                for t=1:nTasks
                    if 1%nTasks<15
                        %直接轮盘赌
                        m_pt=select_task(table(t,:));
                    else
                        %两层轮盘赌
                        temp_list=ones(1,obj.group);
                        group_list{t}=select_task1(table(t,:),obj.group);
                        for i=1:obj.group
                            temp_list(i)=table(t,group_list{t}(i));
                        end
                        m_pt=group_list{t}(select_task(temp_list));
                    end
                    if rand<table(t,m_pt)%0.1 %从前一个任务中迁移一些染色体去繁殖,迁移策略是迁移过去的变量减去前一任务的均值，加上当前任务的均值
                        option=1;
                    else
                        m_pt=t;
                        option=2;
                    end
                    if rand>0.9
                        option=0;
%                         nTransfer=round(0.5*sub_pop);
                    end
                    nTransfer=round(scale(t,m_pt)*sub_pop);
%                     if option==1
                        table1(t,m_pt)=table1(t,m_pt)+nTransfer;
%                     end
                    tempPopulation=population{t}(end:-1:1);                    
                    [~,order]=varOrder2(population{m_pt},population{t},dimTasks(m_pt),dimTasks(t),option);
                    tempPopulation(1:nTransfer)=m_transfer1(population{m_pt},population{t},dimTasks(m_pt),dimTasks(t),nTransfer,order,option);
                    % 任务内交叉变异
                    [offspring,calls] = OperatorGA.generate(1, tempPopulation, Tasks(t), obj.mu, obj.mum);
%                     obj.F = 0.1 + (2 - 0.1) * rand;
%                     obj.CR = 0.1 + (0.9 - 0.1) * rand;
%                     [offspring,calls] = OperatorDE.generate(1, tempPopulation, Tasks(t), obj.F, obj.CR, 'current_rand');
%                     [offspring,calls] = OperatorDE.generate(1, tempPopulation, Tasks(t),  obj.F, obj.CR);
                    fnceval_calls=fnceval_calls+calls;
                    % selection
                    intpopulation(1:sub_pop)=offspring;
                    intpopulation(sub_pop+1:2*sub_pop)=population{t};
                    [~,idsCost]=sort([intpopulation.factorial_costs]);
                    intpopulation=intpopulation(idsCost);
                    population{t}=intpopulation(1:sub_pop);
%                     保存最优解
                    if intpopulation(1).factorial_costs<=bestobj(t)&&intpopulation(1).factorial_costs>=0
                        bestobj(t)=intpopulation(1).factorial_costs;
                        data.bestX{t}=intpopulation(1).rnvec;
                    end
                    data.convergence(t, generation) = bestobj(t);
                    pop=population{t}(end:-1:1);
                    [~,ia]=intersect(reshape([pop.rnvec],dimTasks(t),sub_pop)',reshape([offspring.rnvec],dimTasks(t),sub_pop)','rows');
                    scale(t,m_pt)=sum(ia)/(sub_pop/2*(sub_pop+1));
                    scale(t,m_pt)=obj.min+scale(t,m_pt)*(0.5-obj.min);
                    if m_pt==t && option~=0
                        trans(t)=scale(t,m_pt);
                    end
                    if m_pt~=t && option~=0
                        temp=(scale(t,m_pt)-scale(t,t))/(scale(t,m_pt)+scale(t,t));
                        obj.w=0.1+rand*(0.9-0.1);
%                         table(t,m_pt)=obj.Lb+(obj.w*table(t,m_pt)+(1-obj.w)*temp)*(obj.Ub-obj.Lb);
                        table(t,m_pt)=obj.Lb+obj.w*(table(t,m_pt)-obj.Lb)+(1-obj.w)*temp*(obj.Ub-obj.Lb);
                        if table(t,m_pt)<obj.Lb || isnan(table(t,m_pt))
                            table(t,m_pt)=obj.Lb;
                        end
                        if table(t,m_pt)>obj.Ub
                            table(t,m_pt)=obj.Ub;
                        end
                    end
                end
%                 disp(scale)
%                 disp(table)
            end
%             disp(table1)
%             disp(bestobj)
            data.bestX = uni2real(data.bestX, Tasks);
            data.clock_time = toc;
        end
    end
end