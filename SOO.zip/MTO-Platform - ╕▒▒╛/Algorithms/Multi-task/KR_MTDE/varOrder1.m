function [sums,order]= varOrder1(prev,this,prevDims,thisDims,option)
%VARORDER1 种群中个体的决策变量顺序匹配问题
%   将两种群中个体的每个决策变量到该决策变量均值的平均距离最近的匹配
%prev代表前一种群，mPrev代表前一种群的均值; this代表当前种群，mThis代表当前种群的均值,option代表选择距离最大还是最小
prevMax=max(reshape([prev.rnvec],prevDims,[]),[],2)';
prevMin=min(reshape([prev.rnvec],prevDims,[]),[],2)';
thisMax=max(reshape([this.rnvec],thisDims,[]),[],2)';
thisMin=min(reshape([this.rnvec],thisDims,[]),[],2)';
prevRange=prevMax-prevMin;
thisRange=thisMax-thisMin;

mPrev=mean(reshape([prev.rnvec],prevDims,[]),2)';
mThis=mean(reshape([this.rnvec],thisDims,[]),2)';
temp1=power((reshape([prev.rnvec],prevDims,[])'-mPrev),2);
temp2=power((reshape([this.rnvec],thisDims,[])'-mThis),2);

sum2=sum(temp2,1);
sums=0;order=zeros(1,thisDims);
if option ==1 
    opt=1;
end
if option ==0
    opt=randi([1,prevDims]);
end
if option ==2 
    opt=2;
end

for i=1:thisDims
    for j=1:prevDims
        if  prevRange(j)~=thisRange(i)
            temp1(j)=power(power(temp1(j),1/2)*(thisRange(i)/prevRange(j)),2);
        end
    end
    sum1=sum(temp1,1);
    [d,a]=sort(power(sum1-sum2(i),2));
    sums=sums+d(opt);
    order(i)=a(opt);
    %控制范围，不大于1.1，小的不需要放大，但是大的需要缩小。因为小的符合我们种群当前的发展趋势，
    %按照此趋势发展，应该会收敛到这个大小。
    
end
end
