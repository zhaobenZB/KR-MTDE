classdef MTGA < Algorithm
    % <Multi> <None>

    properties (SetAccess = private)
        pTransfer=0.4
        mu = 2;
        mum = 5;
    end

    methods
        function parameter = getParameter(obj)
            parameter = {'pTransfer: Portion of chromosomes to transfer from one task to another', num2str(obj.pTransfer), ...
                        'mu: index of Simulated Binary Crossover', num2str(obj.mu), ...
                        'mum: index of polynomial mutation', num2str(obj.mum)};
        end

        function obj = setParameter(obj, parameter_cell)
            count = 1;
            obj.pTransfer = str2double(parameter_cell{count}); count = count + 1;
            obj.mu = str2double(parameter_cell{count}); count = count + 1;
            obj.mum = str2double(parameter_cell{count}); count = count + 1;
        end

        function data = run(obj, Tasks, run_parameter_list)
            sub_pop = run_parameter_list(1);
            sub_eva = run_parameter_list(2);
            pop_size = sub_pop * length(Tasks);
            eva_num = sub_eva * length(Tasks);
            tic
            nTasks=length(Tasks);
            scale=ones(nTasks,nTasks); % adjust nTransfer dynamically
            nTransfer0=round(obj.pTransfer*sub_pop);
            for i=1:nTasks
                dimTasks(i) = Tasks(i).dims;
            end
            % initialize
            [population, fnceval_calls, bestobj, data.bestX] = initializeMT(Individual, sub_pop, Tasks, [Tasks.dims]);
            data.convergence(:, 1) = bestobj;
            
            generation = 1;
            while fnceval_calls < eva_num
                generation = generation + 1;
                for t=1:nTasks
                    for prevTask=1:nTasks
                        if t~=prevTask
                    %从前一个任务中迁移一些染色体去繁殖
                    %迁移策略是迁移过去的变量减去前一任务的均值，加上当前任务的均值
                    nTransfer=round(scale(t,prevTask)*nTransfer0);
                    mPrev=mean(reshape([population{prevTask}(1:nTransfer).rnvec],dimTasks(prevTask),nTransfer),2)';
                    mThis=mean(reshape([population{t}(1:nTransfer).rnvec],dimTasks(t),nTransfer),2)';
                    tempPopulation=population{t}(end:-1:1);
                    if dimTasks(t)>dimTasks(prevTask) % the previous task has a smaller dimensionality
                        for i=1:nTransfer
                            tempPopulation(i).rnvec(1:dimTasks(prevTask))=population{prevTask}(i).rnvec(1:dimTasks(prevTask));
                        end
                        %if gen<600
                        tempPopulation(nTransfer).rnvec(1:dimTasks(prevTask))=population{prevTask}(1).rnvec(1:dimTasks(prevTask))+mThis(1:dimTasks(prevTask))-mPrev(1:dimTasks(prevTask));
                        %end
                    else
                        for i=1:nTransfer
                            tempPopulation(i).rnvec=population{prevTask}(i).rnvec(1:dimTasks(t));
                        end
                        %if gen<600
                        tempPopulation(nTransfer).rnvec=population{prevTask}(1).rnvec(1:dimTasks(t))+mThis(1:dimTasks(t))-mPrev(1:dimTasks(t));
                        %end
                    end
                    % 任务内交叉变异
                    [offspring,calls] = OperatorGA.generate(1, tempPopulation, Tasks(t), obj.mu, obj.mum);
                    fnceval_calls=fnceval_calls+calls;
                    
                    intpopulation(1:sub_pop)=offspring;
                    intpopulation(sub_pop+1:2*sub_pop)=population{t};
                    % remove the duplicates in intpopulation
                    %删除 intpopulation 中的重复项
                    [rnvec,idsUnique]=unique(reshape([intpopulation.rnvec],dimTasks(t),2*sub_pop)','rows');
                    intpopulation=intpopulation(idsUnique);
                    [~,idsCost]=sort([intpopulation.factorial_costs]);
                    intpopulation=intpopulation(idsCost); rnvec=rnvec(idsCost,:);
                    %保存最优解
                    if intpopulation(1).factorial_costs<=bestobj(t)
                        bestobj(t)=intpopulation(1).factorial_costs;
                        data.bestX{t}=intpopulation(1).rnvec;
                    end
                    data.convergence(t, generation) = bestobj(t);
                    
                    %选择策略：精英选择
                    if length(intpopulation)>=sub_pop
                        population{t}=intpopulation(1:sub_pop);
                    else
                        population{t}(1:length(intpopulation))=intpopulation;
                        for i=length(intpopulation)+1:sub_pop
                            population{t}(i) = Individual();
                            population{t}(i).rnvec = rand(1, dim);
                        end
                        [population{t}(length(intpopulation):sub_pop), calls] = evaluate(population{t}(length(intpopulation):sub_pop), Task, 1);
                        fnceval_calls = fnceval_calls+calls;
                    end
                    % Update scale by rank
                    [~,ia]=intersect(rnvec,reshape([offspring(1:2:2*nTransfer-1).rnvec],dimTasks(t),nTransfer)','rows');
                    mRank=mean(ia);
                    scale(t,prevTask)=min(1.5,max(.6,(.3-(mRank/length(intpopulation)-.25*obj.pTransfer))/.2));
                    scale(prevTask,t)=scale(t,prevTask);
                        end
                    end
                end
            end
            data.bestX = uni2real(data.bestX, Tasks);
            data.clock_time = toc;
        end
    end
end
