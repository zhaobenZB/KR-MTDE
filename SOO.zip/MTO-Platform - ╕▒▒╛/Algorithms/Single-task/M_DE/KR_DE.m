classdef KR_DE < Algorithm
    % <Single> <None>

    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 Yanchi Li. You are free to use the MTO-Platform for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "MTO-Platform" and cite
    % or footnote "https://github.com/intLyc/MTO-Platform"
    %--------------------------------------------------------------------------

    properties (SetAccess = private)
        F = 0.5
        CR = 0.9
        trans=0.5;
        min=0.1;
    end

    methods
        function parameter = getParameter(obj)
            parameter = {'F: Mutation Factor', num2str(obj.F), ...
                        'CR: Crossover Probability', num2str(obj.CR),...
                        'trans:number of transfer',num2str(obj.trans),...
                        'min: Minimum boundary value', num2str(obj.min)};
        end

        function obj = setParameter(obj, parameter_cell)
            count = 1;
            obj.F = str2double(parameter_cell{count}); count = count + 1;
            obj.CR = str2double(parameter_cell{count}); count = count + 1;
            obj.trans = str2double(parameter_cell{count});count = count + 1;
            obj.min = str2double(parameter_cell{count});
        end

        function data = run(obj, Tasks, run_parameter_list)
            sub_pop = run_parameter_list(1);
            sub_eva = run_parameter_list(2);
            tic

            data.convergence = [];
            data.bestX = {};
            tic

            for sub_task = 1:length(Tasks)
                Task = Tasks(sub_task);

                % initialize
                [population, fnceval_calls, bestobj, bestX] = initialize(Individual, sub_pop, Task, Task.dims);
                convergence(1) = bestobj;

                generation = 1;
                while fnceval_calls < sub_eva
                    generation = generation + 1;
                    nTransfer=round(obj.trans*sub_pop);
%                     nTransfer=round(0.4*sub_pop);
                    %迁移自己的解
                    tempPopulation=population(end:-1:1);
                    if rand<0.9
                        option=2;
                    else
                        option=0;
                    end
                    [~,order]=varOrder2(population,population,Task.dims,Task.dims,option);%round(sub_pop*obj.trans)
                    tempPopulation(1:nTransfer)=m_transfer1(population,population,Task.dims,Task.dims,nTransfer,order,option);

                    % generation
                    
%                     obj.F = 0.1 + (2 - 0.1) * rand;
%                     obj.CR = 0.1 + (0.9 - 0.1) * rand;
%                     [offspring,calls] = OperatorDE.generate(1, tempPopulation, Task, obj.F, obj.CR, 'current_rand');
                    [offspring,calls] = OperatorDE.generate(1, tempPopulation, Task, obj.F, obj.CR, 'best_1');

%                     [offspring, calls] = OperatorDE.generate(1, tempPopulation, Task, obj.F, obj.CR);
                    fnceval_calls = fnceval_calls + calls;

                    % selection
%                     replace = [population.factorial_costs] > [offspring.factorial_costs];
%                     population(replace) = offspring(replace);
                    population = [population, offspring];
                    [~, rank] = sort([population.factorial_costs]);
                    population = population(rank(1:sub_pop));
                    [bestobj_now, idx] = min([population.factorial_costs]);
                    if bestobj_now < bestobj&& bestobj_now>=0
                        bestobj = bestobj_now;
                        bestX = population(idx).rnvec;
                    end
                    convergence(generation) = bestobj;
                    [~, rank] = sort([population.factorial_costs]);
                    population = population(rank);
                    pop=population(end:-1:1);
                    [~,ia]=intersect(reshape([pop.rnvec],Task.dims,sub_pop)',reshape([offspring.rnvec],Task.dims,sub_pop)','rows');

                    obj.trans=sum(ia)/(sub_pop/2*(sub_pop+1));
                    obj.trans=obj.min+obj.trans*(0.5-obj.min);
%                     disp(obj.trans)
%                     if obj.trans>0.5
%                         obj.trans=0.5;
%                     end
%                     if obj.trans<obj.min
%                         obj.trans=obj.min;
%                     end
                end
                data.convergence = [data.convergence; convergence];
                data.bestX = [data.bestX, bestX];
            end
            data.bestX = uni2real(data.bestX, Tasks);
            data.clock_time = toc;
        end
    end
end
